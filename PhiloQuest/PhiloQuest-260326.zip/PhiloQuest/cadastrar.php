<?php
// Configurações iniciais e Autoload
require_once 'vendor/autoload.php';

use PhiloQuest\Services\AuthService;

$mensagem = "";
$tipoMensagem = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomeCompleto = trim($_POST['nome_completo'] ?? '');
    $matricula = trim($_POST['matricula'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $tipoUsuario = $_POST['tipo_usuario'] ?? 'ALUNO';
    
    // Captura o código da turma (será validado apenas se for aluno)
    $codigoTurma = trim($_POST['codigo_turma'] ?? '');

    // NOVA REGRA BACKEND: 3 números + 2 letras + 4 números do ano (Ex: 103HS2026)
    $padraoTurma = '/^\d{3}[a-zA-Z]{2}\d{4}$/';

    // Validação de campos obrigatórios gerais
    if (empty($nomeCompleto) || empty($matricula) || empty($senha)) {
        $mensagem = "Por favor, preencha todos os campos obrigatórios.";
        $tipoMensagem = "msg-error";
    } else {
        // Agora instanciamos o AuthService, que cuida da lógica de negócio
        $authService = new AuthService();
        $sucesso = false;

        // Fluxo 1: Cadastro de Aluno
        if ($tipoUsuario === 'ALUNO') {
            if (empty($codigoTurma)) {
                $mensagem = "O código da turma é obrigatório para alunos.";
                $tipoMensagem = "msg-error";
            } elseif (!preg_match($padraoTurma, $codigoTurma)) {
                $mensagem = "Código de turma inválido. Use o padrão Ex: 103HS2026.";
                $tipoMensagem = "msg-error";
            } else {
                // Delega a criação e o salvamento para o Service
                $sucesso = $authService->registrarAluno($matricula, $nomeCompleto, $senha, $codigoTurma);
                $mensagemErroBanco = "Erro: Matrícula já existe ou Turma não encontrada no sistema.";
            }
        } 
        // Fluxo 2: Cadastro de Professor
        elseif ($tipoUsuario === 'PROFESSOR') {
            // Delega a criação e o salvamento para o Service
            $sucesso = $authService->registrarProfessor($matricula, $nomeCompleto, $senha);
            $mensagemErroBanco = "Erro: Esta matrícula já está cadastrada no sistema.";
        }

        // Feedback de sucesso ou falha no banco
        if ($sucesso) {
            $mensagem = "Cadastro realizado com sucesso! Faça <a href='login.php'>Login</a>.";
            $tipoMensagem = "msg-success";
        } elseif (empty($mensagem)) { // Se a variável $mensagem estiver vazia, falhou no DB
            $mensagem = $mensagemErroBanco;
            $tipoMensagem = "msg-error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PhiloQuest - Cadastro</title>
    <link rel="stylesheet" href="css/cadastro.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 50px; height: 50px;">
                <circle cx="50" cy="50" r="50" fill="#9e39f7"/>
                <path d="M50 8C38.9543 8 30 16.9543 30 28C30 39.0457 38.9543 48 50 48" stroke="white" stroke-width="6" stroke-linecap="round"/>
                <path d="M50 8C61.0457 8 70 16.9543 70 28C70 39.0457 61.0457 48 50 48" stroke="white" stroke-width="6" stroke-linecap="round"/>
                <path d="M50 48C50 59.0457 41.0457 68 30 68" stroke="white" stroke-width="6" stroke-linecap="round"/>
                <path d="M50 48C50 59.0457 58.9543 68 70 68" stroke="white" stroke-width="6" stroke-linecap="round"/>
                <circle cx="30" cy="80" r="6" fill="white"/>
                <circle cx="70" cy="80" r="6" fill="white"/>
            </svg>
            <div class="logo-text">PhiloQuest</div>
        </div>

        <div class="card">
            <h2>Bem-vindo</h2>
            <div class="subtitle">Cadastre-se para começar sua jornada</div>
            
            <div class="tabs">
                <a href="login.php" class="tab">Entrar</a>
                <a href="cadastrar.php" class="tab active">Cadastrar</a>
            </div>

            <?php if ($mensagem): ?>
                <div class="msg-alert <?php echo $tipoMensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>
            
            <form id="formCadastro" method="POST">
                
                <div class="user-type-selector">
                    <input type="radio" id="tipo_aluno" name="tipo_usuario" value="ALUNO" <?php echo ($tipoUsuario === 'ALUNO') ? 'checked' : ''; ?>>
                    <label for="tipo_aluno">Sou Aluno</label>

                    <input type="radio" id="tipo_prof" name="tipo_usuario" value="PROFESSOR" <?php echo ($tipoUsuario === 'PROFESSOR') ? 'checked' : ''; ?>>
                    <label for="tipo_prof">Sou Professor</label>
                </div>

                <div class="form-group">
                    <label for="nome_completo">Nome Completo</label>
                    <input type="text" id="nome_completo" name="nome_completo" placeholder="João Silva" required value="<?php echo htmlspecialchars($_POST['nome_completo'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label for="matricula">Matrícula</label>
                    <input type="text" id="matricula" name="matricula" placeholder="Ex: 2024001" required value="<?php echo htmlspecialchars($_POST['matricula'] ?? ''); ?>">
                </div>
                
                <div class="form-group" id="grupo_turma">
                    <label for="codigo_turma">Código da Turma</label>
                    <input type="text" id="codigo_turma" name="codigo_turma" placeholder="Ex: 103HS2026" required value="<?php echo htmlspecialchars($_POST['codigo_turma'] ?? ''); ?>">
                    <span id="erroTurma" class="error-msg" style="color: red; display: none;"></span>
                </div>

                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" id="senha" name="senha" placeholder="••••••••" required>
                </div>
                
                <button type="submit">Cadastrar</button>
            </form>
        </div>
    </div>

    <script src="js/validacao.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const radioProf = document.getElementById('tipo_prof');
            if (radioProf && radioProf.checked) {
                // Dispara o evento change para ocultar a turma se voltar do PHP marcado como Professor
                radioProf.dispatchEvent(new Event('change'));
            }
        });
    </script>
</body>
</html>