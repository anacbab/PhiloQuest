-- Criação do Banco de Dados
CREATE DATABASE IF NOT EXISTS philoquest CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE philoquest;

-- --------------------------------------------------------
-- 1. TABELA DE TURMAS 
-- (Criada primeiro para o aluno poder se vincular depois)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_turma VARCHAR(20) NOT NULL UNIQUE, 
    professor_matricula VARCHAR(50) NOT NULL, 
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------
-- 2. TABELA DE USUÁRIOS (Padrão Single Table Inheritance)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    matricula VARCHAR(50) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    tipo_usuario ENUM('ALUNO', 'PROFESSOR', 'ADMIN') NOT NULL, 
    
    -- Colunas exclusivas do Aluno (Permitem NULL caso seja um Professor ou Admin)
    xp_acumulado INT DEFAULT 0,
    turma_id INT NULL,
    
    FOREIGN KEY (turma_id) REFERENCES turmas(id) ON DELETE SET NULL
);

-- Agora que a tabela usuários existe, adicionamos a restrição (FK) do professor na turma
ALTER TABLE turmas 
ADD CONSTRAINT fk_turma_professor 
FOREIGN KEY (professor_matricula) REFERENCES usuarios(matricula) ON DELETE CASCADE;

-- --------------------------------------------------------
-- 3. TABELA DE CARTAS CONCEITUAIS
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS cartas_conceituais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_filosofo VARCHAR(100) NOT NULL,
    citacao TEXT NOT NULL,
    raridade ENUM('COMUM', 'RARA', 'EPICA', 'LENDARIA') NOT NULL
);

-- --------------------------------------------------------
-- 4. TABELA DE RELACIONAMENTO: ALUNOS <-> CARTAS (Muitos para Muitos)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS alunos_cartas (
    aluno_matricula VARCHAR(50) NOT NULL,
    carta_id INT NOT NULL,
    desbloqueada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (aluno_matricula, carta_id),
    FOREIGN KEY (aluno_matricula) REFERENCES usuarios(matricula) ON DELETE CASCADE,
    FOREIGN KEY (carta_id) REFERENCES cartas_conceituais(id) ON DELETE CASCADE
);

-- --------------------------------------------------------
-- 5. TABELA DE MISSÕES
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS missoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(150) NOT NULL,
    descricao TEXT NOT NULL,
    xp_recompensa INT NOT NULL,
    data_limite DATETIME NOT NULL,
    professor_matricula VARCHAR(50) NOT NULL,
    
    FOREIGN KEY (professor_matricula) REFERENCES usuarios(matricula) ON DELETE CASCADE
);

-- --------------------------------------------------------
-- 6. TABELA DE SUBMISSÕES DE ETAPAS
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS submissoes_etapa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aluno_matricula VARCHAR(50) NOT NULL,
    conteudo TEXT NOT NULL,
    status ENUM('AGUARDANDO_VALIDACAO', 'APROVADO', 'NECESSITA_REVISAO') DEFAULT 'AGUARDANDO_VALIDACAO',
    data_envio DATETIME NOT NULL,
    
    FOREIGN KEY (aluno_matricula) REFERENCES usuarios(matricula) ON DELETE CASCADE
);

-- =========================================================================
-- CARGA DE DADOS INICIAIS (SEEDING)
-- =========================================================================

-- 1. Inserir o Administrador Master (Não possui turma)
-- Senha de teste: 'admin123' 
INSERT IGNORE INTO usuarios (matricula, nome, senha_hash, tipo_usuario, turma_id) 
VALUES (
    'ADMIN001', 
    'Administrador do Sistema', 
    '$2y$10$8sA2N5Sx/1zMQv2xcQwPT.E3KzP9V6H3d1wPzB3b2O8lM8z1Z2K9m', 
    'ADMIN', 
    NULL
);

-- 2. Inserir um Professor de Teste
-- Senha de teste: 'prof123' 
INSERT IGNORE INTO usuarios (matricula, nome, senha_hash, tipo_usuario, turma_id) 
VALUES (
    'PROF2026', 
    'Sócrates', 
    '$2y$10$wN9iL6U.6wO.Zf6p6jL/aOMlK1P2Q5f/3j.P/h/L/m/G/e/B.r/sC', 
    'PROFESSOR', 
    NULL
);

-- 3. Inserir uma Turma com a NOVA regra (3 números + 2 letras + Ano)
-- Sem o campo nome_turma, apenas o código da turma vinculado ao professor.
INSERT IGNORE INTO turmas (codigo_turma, professor_matricula) 
VALUES ('103HS2026', 'PROF2026');