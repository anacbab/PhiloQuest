<?php
namespace PhiloQuest\Services;

use PhiloQuest\Repositories\UsuarioRepository;
use PhiloQuest\Entidades\Usuario;
use PhiloQuest\Entidades\Aluno;
use PhiloQuest\Entidades\Professor;
use PhiloQuest\Entidades\Administrador;

class AuthService {
    
    // Mantendo a sua Injeção de Dependência elegante do PHP 8
    public function __construct(
        private ?UsuarioRepository $usuarioRepository = null
    ) {
        // Fallback: se não for injetado, ele instancia automaticamente (evita quebrar o cadastrar.php)
        if ($this->usuarioRepository === null) {
            $this->usuarioRepository = new UsuarioRepository();
        }
    }

    /**
     * Atualizado para retornar o Objeto Usuario em vez de apenas bool.
     * Assim o controlador consegue saber quem logou para fazer o redirecionamento.
     */
    public function login(string $matricula, string $senhaNaoCriptografada): ?Usuario {
        $usuario = $this->usuarioRepository->buscarPorMatricula($matricula);

        if ($usuario && password_verify($senhaNaoCriptografada, $usuario->getSenhaHash())) {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            
            // Suas variáveis originais mantidas
            $_SESSION['usuario_logado'] = true;
            $_SESSION['matricula'] = $usuario->getMatricula();
            $_SESSION['nome'] = $usuario->getNome();
            
            // NOVA VARIÁVEL VITAL: Necessária para o roteamento do sistema
            $_SESSION['tipo_usuario'] = $usuario->getTipoUsuario(); 
            
            return $usuario; // Retorna o usuário logado com sucesso
        }
        
        return null; // Retorna null se a senha ou matrícula estiverem erradas
    }

    /**
     * Redireciona o usuário para o painel correto com base no seu tipo.
     */
    public function redirecionarAposLogin(Usuario $usuario): void {
        switch ($usuario->getTipoUsuario()) {
            case 'ADMIN':
                header('Location: painel-admin.php');
                break;
            case 'PROFESSOR':
                header('Location: painel-professor.php');
                break;
            case 'ALUNO':
            default:
                header('Location: painel-aluno.php');
                break;
        }
        exit;
    }

    /**
     * Registra um novo aluno com vínculo obrigatório a uma turma.
     */
    public function registrarAluno(string $matricula, string $nome, string $senha, string $codigoTurma): bool {
        $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
        $aluno = new Aluno($matricula, $nome, $senhaHash);
        
        return $this->usuarioRepository->cadastrarAlunoComTurma($aluno, $codigoTurma);
    }

    /**
     * Registra um novo professor (sem turma vinculada).
     */
    public function registrarProfessor(string $matricula, string $nome, string $senha): bool {
        $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
        $professor = new Professor($matricula, $nome, $senhaHash);
        
        return $this->usuarioRepository->cadastrarProfessor($professor);
    }

    /**
     * O seu método original, intocado, pois estava perfeito.
     */
    public function logout(): void {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_unset();
        session_destroy();
    }
}