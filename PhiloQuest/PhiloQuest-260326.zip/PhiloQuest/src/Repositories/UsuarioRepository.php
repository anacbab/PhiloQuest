<?php
namespace PhiloQuest\Repositories;

use PhiloQuest\Entidades\Usuario;
use PhiloQuest\Entidades\Aluno;
use PhiloQuest\Entidades\Professor;
use PhiloQuest\Entidades\Administrador; // Atualizado para usar a sua classe
use PDO;
use PDOException;

class UsuarioRepository {
    private PDO $conexao;

    public function __construct() {
        // Presumindo que sua classe de conexão estática está disponível globalmente ou via autoload
        $this->conexao = \ConexaoBanco::getConexao(); 
    }

    public function buscarPorMatricula(string $matricula): ?Usuario {
        // Busca os dados fundamentais para montar o objeto correto
        $sql = "SELECT matricula, nome, senha_hash, tipo_usuario, xp_acumulado, turma_id 
                FROM usuarios 
                WHERE matricula = :matricula LIMIT 1";
        
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindParam(':matricula', $matricula);
        $stmt->execute();

        $dados = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$dados) {
            return null; // Usuário não encontrado no banco
        }

        // Mapeamento Objeto-Relacional (ORM) manual baseado no tipo_usuario
        if ($dados['tipo_usuario'] === 'ALUNO') {
            $aluno = new Aluno($dados['matricula'], $dados['nome'], $dados['senha_hash']);
            if ($dados['xp_acumulado'] > 0) {
                // Alimenta o XP caso o aluno já tenha progresso
                $aluno->adicionarXp($dados['xp_acumulado']);
            }
            return $aluno;
        }

        if ($dados['tipo_usuario'] === 'PROFESSOR') {
            return new Professor($dados['matricula'], $dados['nome'], $dados['senha_hash']);
        }

        if ($dados['tipo_usuario'] === 'ADMIN') {
            // Instancia a classe Administrador com os métodos de negócio que você criou
            return new Administrador($dados['matricula'], $dados['nome'], $dados['senha_hash']);
        }

        return null; // Caso caia em um tipo não mapeado (segurança)
    }

    public function cadastrarAlunoComTurma(Aluno $aluno, string $codigoTurma): bool {
        try {
            // 1. Busca o ID real da Turma no banco usando apenas o código
            $sqlTurma = "SELECT id FROM turmas WHERE codigo_turma = :codigo_turma LIMIT 1";
            $stmtTurma = $this->conexao->prepare($sqlTurma);
            $stmtTurma->bindValue(':codigo_turma', strtoupper($codigoTurma));
            $stmtTurma->execute();
            
            $turma = $stmtTurma->fetch(PDO::FETCH_ASSOC);

            if (!$turma) {
                return false; // Turma não existe, falha o cadastro do aluno
            }

            // 2. Insere o aluno vinculando à turma encontrada
            $sql = "INSERT INTO usuarios (matricula, nome, senha_hash, tipo_usuario, turma_id) 
                    VALUES (:matricula, :nome, :senha_hash, 'ALUNO', :turma_id)";
            
            $stmt = $this->conexao->prepare($sql);
            $stmt->bindValue(':matricula', $aluno->getMatricula());
            $stmt->bindValue(':nome', $aluno->getNome());
            $stmt->bindValue(':senha_hash', $aluno->getSenhaHash());
            $stmt->bindValue(':turma_id', $turma['id']);

            return $stmt->execute();

        } catch (PDOException $e) {
            // Em produção, você usaria error_log($e->getMessage());
            return false;
        }
    }

    public function cadastrarProfessor(Professor $professor): bool {
        try {
            // Professores não recebem turma_id no momento do cadastro (é inserido como NULL)
            $sql = "INSERT INTO usuarios (matricula, nome, senha_hash, tipo_usuario, turma_id) 
                    VALUES (:matricula, :nome, :senha_hash, 'PROFESSOR', NULL)";
            
            $stmt = $this->conexao->prepare($sql);
            
            $stmt->bindValue(':matricula', $professor->getMatricula());
            $stmt->bindValue(':nome', $professor->getNome());
            $stmt->bindValue(':senha_hash', $professor->getSenhaHash());

            return $stmt->execute();

        } catch (PDOException $e) {
            return false;
        }
    }
}