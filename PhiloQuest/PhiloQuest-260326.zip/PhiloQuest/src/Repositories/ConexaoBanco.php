<?php
namespace PhiloQuest\Repositories;

use PDO;
use PDOException;

class ConexaoBanco {
    // Armazena a instância única da conexão
    private static ?PDO $instancia = null;

    // Configurações do banco (ajuste conforme o seu ambiente local)
    private const HOST = 'localhost';
    private const DBNAME = 'philoquest';
    private const USER = 'root';
    private const PASSWORD = ''; // Coloque sua senha do MySQL aqui, se houver

    // O construtor privado impede que a classe seja instanciada com "new"
    private function __construct() {}

    public static function getConexao(): PDO {
        // Se a conexão ainda não existir, nós a criamos
        if (self::$instancia === null) {
            try {
                $dsn = "mysql:host=" . self::HOST . ";dbname=" . self::DBNAME . ";charset=utf8mb4";
                
                self::$instancia = new PDO($dsn, self::USER, self::PASSWORD);
                
                // Configura o PDO para lançar exceções em caso de erro no SQL
                self::$instancia->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                // Define o formato de retorno padrão como array associativo
                self::$instancia->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                
            } catch (PDOException $e) {
                // Em um ambiente real, você salvaria esse erro em um arquivo de log
                die("Erro de conexão com o banco de dados: " . $e->getMessage());
            }
        }

        return self::$instancia;
    }
}