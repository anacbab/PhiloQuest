<?php
namespace PhiloQuest\Enum;

enum StatusSubmissao: string {
    case AGUARDANDO_VALIDACAO = 'AGUARDANDO_VALIDACAO';
    case APROVADO = 'APROVADO';
    case NECESSITA_REVISAO = 'NECESSITA_REVISAO';
}