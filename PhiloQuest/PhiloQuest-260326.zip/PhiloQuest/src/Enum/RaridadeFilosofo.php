<?php
namespace PhiloQuest\Enum;

enum RaridadeFilosofo: string {
    case COMUM = 'COMUM';
    case RARA = 'RARA';
    case EPICA = 'EPICA';
    case LENDARIA = 'LENDARIA';
}